import { kv } from "@vercel/kv";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");

  if (req.method === "GET") {
    try {
      const ids = await kv.lrange("meetings_list", 0, 49);
      const evals = [];

      for (const id of ids) {
        const evalRaw = await kv.get(`eval_${id}`);
        if (evalRaw) {
          evals.push(typeof evalRaw === "string" ? JSON.parse(evalRaw) : evalRaw);
        }
      }

      return res.status(200).json({ evaluations: evals.reverse() });
    } catch (e) {
      return res.status(500).json({ error: "Erro ao buscar avaliações", detail: e.message });
    }
  }

  return res.status(405).json({ error: "Method not allowed" });
}
