import { kv } from "@vercel/kv";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");

  if (req.method === "GET") {
    try {
      const ids = await kv.lrange("meetings_list", 0, 49);
      const meetings = await Promise.all(
        ids.map(async id => {
          const raw = await kv.get(id);
          return typeof raw === "string" ? JSON.parse(raw) : raw;
        })
      );
      return res.status(200).json({ meetings: meetings.filter(Boolean).reverse() });
    } catch (e) {
      return res.status(500).json({ error: "Erro ao buscar reuniões", detail: e.message });
    }
  }

  return res.status(405).json({ error: "Method not allowed" });
}
