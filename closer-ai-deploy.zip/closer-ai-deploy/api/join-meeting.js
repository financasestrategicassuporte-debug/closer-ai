import { kv } from "@vercel/kv";

const FIREFLIES_API = "https://api.fireflies.ai/graphql";

async function firefliesRequest(query, variables = {}) {
  const res = await fetch(FIREFLIES_API, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${process.env.FIREFLIES_API_KEY}`
    },
    body: JSON.stringify({ query, variables })
  });
  return res.json();
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { closer, closerId, scriptId, scriptName, scriptSteps, scriptCriteria, meetLink, scheduledAt } = req.body;

  if (!meetLink || !scriptSteps) {
    return res.status(400).json({ error: "meetLink e script são obrigatórios" });
  }

  const meetingId = `meeting_${Date.now()}`;
  const fullLink = meetLink.startsWith("http") ? meetLink : `https://${meetLink}`;

  let firefliesMeetingId = null;
  let botError = null;

  try {
    // Tenta entrar em reunião ao vivo primeiro
    const liveMutation = `
      mutation AddToLiveMeeting($url: String!, $title: String!) {
        addToLiveMeeting(url: $url, title: $title) {
          id
          title
        }
      }
    `;
    const liveData = await firefliesRequest(liveMutation, {
      url: fullLink,
      title: `CloserAI - ${closer} - ${scriptName}`
    });

    if (liveData?.data?.addToLiveMeeting?.id) {
      firefliesMeetingId = liveData.data.addToLiveMeeting.id;
    } else {
      // Agenda o notetaker para reunião futura
      const schedMutation = `
        mutation ScheduleNotetaker($url: String!, $title: String!, $startTime: Long!) {
          scheduleNotetaker(url: $url, title: $title, start_time: $startTime) {
            id
            title
          }
        }
      `;
      const schedTime = scheduledAt ? new Date(scheduledAt).getTime() : (Date.now() + 60000);
      const schedData = await firefliesRequest(schedMutation, {
        url: fullLink,
        title: `CloserAI - ${closer} - ${scriptName}`,
        startTime: schedTime
      });
      firefliesMeetingId = schedData?.data?.scheduleNotetaker?.id || null;
      if (!firefliesMeetingId) {
        botError = liveData?.errors?.[0]?.message || schedData?.errors?.[0]?.message || "Erro ao enviar bot";
      }
    }
  } catch (e) {
    botError = `Erro de conexão: ${e.message}`;
  }

  const meeting = {
    id: meetingId,
    closer,
    closerId,
    scriptId,
    scriptName,
    scriptSteps,
    scriptCriteria,
    meetLink: fullLink,
    scheduledAt: scheduledAt || new Date().toISOString(),
    status: firefliesMeetingId ? "bot_joined" : "scheduled",
    firefliesMeetingId,
    botError,
    createdAt: new Date().toISOString()
  };

  await kv.set(meetingId, JSON.stringify(meeting));
  await kv.lpush("meetings_list", meetingId);

  return res.status(200).json({ success: true, meeting });
}
