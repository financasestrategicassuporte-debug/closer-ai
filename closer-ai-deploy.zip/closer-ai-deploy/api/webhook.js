import { kv } from "@vercel/kv";
import Anthropic from "@anthropic-ai/sdk";

const FIREFLIES_API = "https://api.fireflies.ai/graphql";

async function getFirefliesTranscript(transcriptId) {
  const res = await fetch(FIREFLIES_API, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${process.env.FIREFLIES_API_KEY}`
    },
    body: JSON.stringify({
      query: `
        query Transcript($transcriptId: String!) {
          transcript(id: $transcriptId) {
            id
            title
            date
            duration
            sentences {
              text
              speaker_name
              start_time
              end_time
            }
          }
        }
      `,
      variables: { transcriptId }
    })
  });
  return res.json();
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const body = req.body;

  // Fireflies envia: { meetingId, title, ... } quando a transcrição fica pronta
  const { meetingId: firefliesMeetingId } = body;
  if (!firefliesMeetingId) return res.status(200).json({ received: true });

  // 1. Busca a reunião pelo firefliesMeetingId
  const meetingIds = await kv.lrange("meetings_list", 0, -1);
  let meeting = null;
  let meetingKey = null;

  for (const id of meetingIds) {
    const raw = await kv.get(id);
    const m = typeof raw === "string" ? JSON.parse(raw) : raw;
    if (m?.firefliesMeetingId === firefliesMeetingId) {
      meeting = m;
      meetingKey = id;
      break;
    }
  }

  if (!meeting) return res.status(200).json({ received: true, note: "reunião não encontrada" });

  // 2. Busca a transcrição completa no Fireflies
  let transcript = "";
  try {
    const data = await getFirefliesTranscript(firefliesMeetingId);
    const sentences = data?.data?.transcript?.sentences || [];
    transcript = sentences
      .map(s => `${s.speaker_name || "Participante"}: ${s.text}`)
      .join("\n");
  } catch (e) {
    transcript = "[Erro ao buscar transcrição do Fireflies]";
  }

  // 3. Avalia com Claude (Anthropic) em português
  let evaluation = null;
  try {
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

    const msg = await client.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1500,
      messages: [{
        role: "user",
        content: `Você é um avaliador especialista em reuniões de vendas em português brasileiro.

SCRIPT DA REUNIÃO (o que o closer deveria seguir):
${meeting.scriptSteps}

CRITÉRIOS DE AVALIAÇÃO:
${meeting.scriptCriteria}

TRANSCRIÇÃO DA REUNIÃO:
${transcript}

Avalie a reunião com base nos critérios. Retorne APENAS um JSON válido (sem markdown, sem texto extra):
{
  "score": <número de 0 a 100>,
  "feedback": "<análise detalhada em português, 2-3 parágrafos>",
  "criteria_scores": {
    "<critério exatamente como listado>": <score 0-100>
  },
  "highlights": ["<ponto positivo 1>", "<ponto positivo 2>"],
  "improvements": ["<melhoria 1>", "<melhoria 2>"]
}`
      }]
    });

    const raw = msg.content[0].text.replace(/```json|```/g, "").trim();
    evaluation = JSON.parse(raw);
  } catch (e) {
    evaluation = {
      score: 0,
      feedback: "Erro ao processar avaliação com a IA.",
      criteria_scores: {},
      highlights: [],
      improvements: ["Verifique a variável ANTHROPIC_API_KEY"]
    };
  }

  // 4. Salva avaliação e atualiza reunião
  const evalId = `eval_${meetingKey}`;
  await kv.set(evalId, JSON.stringify({
    id: evalId,
    meetingId: meetingKey,
    closer: meeting.closer,
    scriptName: meeting.scriptName,
    transcript,
    evaluation,
    createdAt: new Date().toISOString()
  }));

  meeting.status = "evaluated";
  meeting.evalId = evalId;
  await kv.set(meetingKey, JSON.stringify(meeting));

  return res.status(200).json({ success: true, score: evaluation.score });
}
